# MAE-Metric-and-MLSD-Preprocessor-Optimization-Using-the-Bada-Yun-Pattern-as-a-Case-Study

Reproducible code and ComfyUI workflows for:

**Conditional Validity of an Angular-Precision Metric for Line-Based ICH Pattern
Generation: A Bada Yun Case Study with Lightweight LoRA and MLSD**

Every quantity below (dataset partition, training cost, group definitions, MAE
pipeline, statistical models) is taken from the current manuscript.

## Repository structure

    bada-yun-mae-repro/
    ├── README.md
    ├── requirements.txt
    ├── scripts/
    │   ├── compute_mae.py            # Step 4: Mean Angular Error (+ principal-axis correction)
    │   ├── compute_pca.py            # Step 4: PCA intrinsic dimensionality (supplementary)
    │   ├── evaluate_metrics.py       # Step 4: SSIM / PSNR / LPIPS / FID
    │   ├── generate_grid.py          # Step 3: 26 x 2 x 5 batch generation driver
    │   └── statistical_analysis.py   # Step 5: mixed-effects model, GAM, segmented regression, TOST
    ├── train_configs/                # Step 2: one config per LoRA rank
    │   ├── lora_rank4.yaml
    │   ├── lora_rank8.yaml
    │   ├── lora_rank16.yaml
    │   └── lora_rank32.yaml
    └── workflows/                    # Step 3: ComfyUI workflows (UI format)
        ├── badayaoxiang_canny.json   # condition C
        ├── badayaoxiang_lineart.json # condition D
        ├── badayaoxiang_mlsd.json    # conditions E (rank-8) and H (rank-32)
        └── badayaoxiang_white.json   # condition F (all-white map)

## Environment

- Python 3.10.12, PyTorch 2.0.1+cu118, CUDA 11.8
- ComfyUI v0.3.0, controlnet_aux 0.0.7
- SD-Trainer Mikazuki v0.6.5 (LoRA training)
- Nvidia RTX 3050 6GB laptop GPU (`--medvram`)
- XnConvert v1.100.0 (image normalisation)

```bash
pip install -r requirements.txt
```

## Reproduction workflow

### Step 1 - Dataset preparation

- 130 internal Bada Yun images retained (Song 48, Shu 40, Yun 42; the Yun row
  includes 15 Nanjing Yunjin versions). Sources: China National Silk Museum,
  Suzhou Silk Museum, Nanjing Yunjin Museum digital archive.
- A further 30 Nanjing Yunjin Bada Yun images are held out entirely as external
  generation references. They are disjoint from the 15 internal Nanjing Yunjin
  images at the image-ID level and were not used in training, validation, or
  model selection.
- XnConvert v1.100.0 normalises all images to 512x512 PNG.
- 4:1 stratified split on the 130 internal images -> 104 training / 26 test.

| Category | Internal original | Training | Test | External |
|----------|------------------:|---------:|-----:|---------:|
| Song     | 48                | 38       | 10   | 0        |
| Shu      | 40                | 32       | 8    | 0        |
| Yun      | 42                | 34       | 8    | 30       |
| Total    | 130               | 104      | 26   | 30       |

### Step 2 - LoRA fine-tuning

Base model: Stable Diffusion v1.5. Trainer: SD-Trainer Mikazuki v0.6.5.
Ranks 4, 8, 16, 32 were trained for 20 epochs (validation loss stabilised after
15) with learning rate 1e-4, batch size 1, AdamW 8bit, fp16, fixed seed 1337.
Only the UNet was fine-tuned; the text encoder was frozen.

```bash
python train.py --config train_configs/lora_rank8.yaml
```

Change `lora.network_dim` (and `train.output_name`) for the other ranks.

| Rank | Training time (104 images) | Model size | Role |
|------|---------------------------:|-----------:|------|
| 4    | 1.4 h                      | 13 MB      | rank selection (excluded) |
| 8    | 1.6 h                      | 26 MB      | main configuration |
| 16   | 2.0 h                      | 52 MB      | rank selection |
| 32   | 2.8 h                      | 104 MB     | Groups B and H |

Rank-8 required 43% less training time and 75% less model size than rank-32.

### Step 3 - Image generation (ComfyUI)

Inference used ComfyUI v0.3.0, DPM++ 2M Karras, 30 steps, CFG = 8, 512x512.
The main set is a **26-source x 2-seed x 5-condition design (260 images)**:
C, D, E, G, H. Supplementary ablation F used 40 images; A and B are
qualitative / non-human references (10 images each).

Group definitions:

| Group | LoRA | ControlNet conditioning | Parameters |
|-------|------|-------------------------|------------|
| A | none | none | native SD 1.5 (10 images) |
| B | rank 32 | none | LoRA only (10 images) |
| C | rank 8 | Canny edge map | low 100, high 200, scale 0.7 |
| D | rank 8 | Lineart | LineartCoarse, guidance 0.8 |
| E | rank 8 | MLSD | thresholds 0.1/0.2, guidance 0.5 |
| F | rank 8 | all-white map | scale 0.7 (40 images) |
| G | none | MLSD | guidance 0.5 |
| H | rank 32 | MLSD | thresholds 0.1/0.2, guidance 0.5 |

The shipped workflows cover C, D, E and F directly. The remaining groups are
derived from them:

- **E** -> `badayaoxiang_mlsd.json` as shipped (LoRA `badayaoxiang_rank8`).
- **H** -> `badayaoxiang_mlsd.json` with the LoraLoader pointing to
  `badayaoxiang_rank32`.
- **D** -> `badayaoxiang_lineart.json`; **C** -> `badayaoxiang_canny.json`.
- **F** -> `badayaoxiang_white.json` (EmptyImage node feeds a solid white map).
- **G** -> `badayaoxiang_mlsd.json` with the LoraLoader bypassed
  (Ctrl+B on the node in ComfyUI).
- **A** -> bypass both the LoraLoader and the ControlNet nodes.
- **B** -> `badayaoxiang_mlsd.json` with the ControlNet nodes bypassed and the
  LoraLoader set to `badayaoxiang_rank32`.

Batch generation: export each condition as an **API-format** workflow
(`Workflow > Export (API)`) into a folder, then run `generate_grid.py`. It
enumerates the 260-cell grid and submits one job per cell to a running ComfyUI
server:

```bash
# enumerate the grid only
python scripts/generate_grid.py --workflow_dir workflows/api --refs refs --dry-run

# real run
python scripts/generate_grid.py --workflow_dir workflows/api --refs refs \
    --server http://127.0.0.1:8188 --out_dir generated
```

### Step 4 - Evaluation metrics

Objective metrics: SSIM and PSNR via Fiji; LPIPS and FID offline in PyTorch with
test-set images as references. LPIPS and FID were computed for completeness but
are not used for inference, because the test set contains only 26 images and FID
is unreliable at this scale.

```bash
python scripts/evaluate_metrics.py --gen_dir generated/E --ref_dir dataset/test --skip_fid
```

**Mean Angular Error (MAE)** - `compute_mae.py`:

1. Otsu thresholding separates foreground from background.
2. Zhang-Suen parallel thinning produces a single-pixel skeleton (implemented
   in-script; no opencv-contrib needed).
3. OpenCV HoughLinesP detects segments (threshold 50, minLineLength 50,
   maxLineGap 10).
4. Orientation is normalised to theta in [0, 180). With A = {0, 45, 90, 135},
   delta_i = min_{a in A} min(|theta_i - a|, 180 - |theta_i - a|), bounded in
   [0, 22.5], and MAE = mean(delta_i).

```bash
python scripts/compute_mae.py --image_dir generated/E --csv mae_E.csv
```

Principal-axis correction (`--correct-axis`) estimates a dominant orientation in
the doubled-angle representation (cos 2*theta, sin 2*theta), weighted by segment
length, and rotates the image to the nearest canonical axis. In the main
experiments the generated images are already in canonical orientation, so MAE is
computed directly without correction; the flag is only for the rotated-input
sensitivity analysis (Group E, corrected: 0.38 +/- 0.12 vs. 0.36 +/- 0.11
uncorrected).

**PCA dimensionality (supplementary)** - `compute_pca.py`: images resized to
128x128, flattened, PCA on the training set, number of components retaining 90%
variance recorded over 100 bootstrap iterations (overall 11.4 +/- 2.2).

```bash
python scripts/compute_pca.py --image_dir dataset/train --by_category
```

### Step 5 - Statistical analysis

`statistical_analysis.py` reads one row per human-rated image
(`image_id, source, condition, mae, rating`) and reproduces Section 2.5:

- linear mixed-effects model `rating ~ mae` with a source random intercept,
  marginal / conditional R^2 (Nakagawa & Schielzeth), ICC, and a Wald-type
  parametric CI (1000 draws);
- descriptive independent-samples one-way ANOVA, two-sample t-tests, and
  Cohen's d with a bootstrap 95% CI (1000 resamples);
- condition-mean regression;
- threshold analysis: thin-plate-spline GAM (edf + approximate F p-value) and
  segmented regression with a bootstrap change-point CI;
- TOST equivalence check with a prespecified 0.10 deg margin.

```bash
python scripts/statistical_analysis.py --csv ratings.csv --margin 0.10
```

The main human-rating set is 130 images (one seed per source-condition cell, 26
sources x 5 conditions including H), each rated by two of the six practitioners
-> 260 main-set ratings. Adding the 30 external images (60 ratings) and the 30
cross-reference-set images (60 ratings) gives the 380-rating practitioner corpus
aggregating to 190 image-level means. Student ratings cover only the main set.

## Notes

- The LoRA weights are not distributed in this repository; train them with
  `train_configs/` or obtain them from the paper's release.
- Image datasets are available upon reasonable request due to institutional
  access restrictions.
- Code and workflows: https://github.com/zx13913865173-Guns/MAE-Metric-and-MLSD-Preprocessor-Optimization-Using-the-Bada-Yun-Pattern-as-a-Case-Study
