#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Step 5: statistical analysis of MAE vs. practitioner judgment.

Paper, Section 2.5 "Statistical Analysis":

  Primary model (linear mixed-effects, source random intercept):
      Rating_ij = beta0 + beta1 * MAE_ij + u_i + e_ij,
      u_i ~ N(0, tau^2),  e_ij ~ N(0, sigma^2).
  "Source" is the 26 held-out test images used as generation references. The
  model does NOT include condition as a fixed effect, so beta1 is a
  source-within, image-level association (exploratory), not a
  condition-controlled effect.
      Fitted to 130 image-level observations across 26 sources:
      beta1 = -1.32, SE = 0.09, t = -14.7, p < 0.001;
      tau^2 = 0.04, sigma^2 = 0.63; ICC = 0.06;
      marginal R^2 = 0.64, conditional R^2 = 0.66.
      95% CI for beta1 by Wald-type parametric simulation (1000 draws):
      [-1.50, -1.14]. Marginal and conditional R^2 follow
      Nakagawa & Schielzeth (2013).

  Threshold analysis: a GAM with a thin-plate spline for MAE (edf = 3.28,
  p = 0.018); segmented regression located a change-point at MAE = 0.59 deg
  (bootstrap 95% CI [0.48, 0.74]).

  Descriptive only (p-values and CIs are NOT used for inferential claims,
  because images share generation sources):
    - independent-samples one-way ANOVA and two-sample t-tests;
    - Cohen's d with bootstrap 95% CI (1000 resamples);
    - condition-mean regression on C, D, E, G (slope = -0.58, r = -0.87);
    - TOST equivalence check with a prespecified 0.10 deg margin.

Input
-----
A CSV with one row per human-rated image and columns:
    image_id, source, condition, mae, rating
  - rating   : two-rater mean geometric-symmetry rating (5-point Likert)
  - condition: one of A..H (the paper's main human rating set = C, D, E, G, H)
Optional column:
    seed       : generation seed (enables the seed-variance summary)

Usage
-----
    python statistical_analysis.py --csv ratings.csv
    python statistical_analysis.py --csv ratings.csv --margin 0.10
"""

import argparse

import numpy as np
import pandas as pd
import statsmodels.formula.api as smf
from scipy import stats

REQUIRED_COLUMNS = ("image_id", "source", "condition", "mae", "rating")


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
def load_data(path):
    df = pd.read_csv(path)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"CSV is missing required columns: {missing}")
    return df


# --------------------------------------------------------------------------- #
# Mixed-effects model
# --------------------------------------------------------------------------- #
def fit_mixed_model(df):
    md = smf.mixedlm("rating ~ mae", df, groups=df["source"])
    return md.fit(reml=True)


def r2_nakagawa(res):
    """Marginal / conditional R^2 and the ICC (Nakagawa & Schielzeth, 2013)."""
    fe = np.asarray(res.fe_params, dtype=float)
    exog = np.asarray(res.model.exog, dtype=float)
    sigma2_f = float(np.var(exog @ fe, ddof=1))          # fixed-effect variance
    tau2 = float(np.asarray(res.cov_re)[0, 0])           # random-intercept var
    sigma2 = float(res.scale)                            # residual variance
    denom = sigma2_f + tau2 + sigma2
    marginal = sigma2_f / denom
    conditional = (sigma2_f + tau2) / denom
    icc = tau2 / (tau2 + sigma2)
    return marginal, conditional, icc, tau2, sigma2, sigma2_f


def wald_parametric_ci(res, n_draws=1000, seed=1337):
    """Wald-type parametric bootstrap CI for beta1 (1000 draws by default)."""
    rng = np.random.default_rng(seed)
    beta = np.asarray(res.fe_params, dtype=float)
    cov = np.asarray(res.cov_params(), dtype=float)[:len(beta), :len(beta)]
    draws = rng.multivariate_normal(beta, cov, size=n_draws)
    lo, hi = np.percentile(draws[:, 1], [2.5, 97.5])
    return float(lo), float(hi)


def report_mixed_model(df):
    res = fit_mixed_model(df)
    beta1 = float(res.fe_params["mae"])
    se = float(res.bse["mae"])
    t = float(res.tvalues["mae"])
    p = float(res.pvalues["mae"])
    lo, hi = wald_parametric_ci(res)
    marginal, conditional, icc, tau2, sigma2, sigma2_f = r2_nakagawa(res)

    print("== Linear mixed-effects model (source random intercept) ==")
    print(f"   n = {int(res.nobs)} image-level obs across "
          f"{df['source'].nunique()} sources")
    print(f"   beta1 = {beta1:.2f}  SE = {se:.2f}  t = {t:.1f}  p = {p:.3g}")
    print(f"   95% CI (Wald parametric, 1000 draws) = [{lo:.2f}, {hi:.2f}]")
    print(f"   tau^2 = {tau2:.2f}  sigma^2 = {sigma2:.2f}  ICC = {icc:.2f}")
    print(f"   marginal R^2 = {marginal:.2f}  conditional R^2 = {conditional:.2f}")
    return res


# --------------------------------------------------------------------------- #
# Descriptive tests
# --------------------------------------------------------------------------- #
def one_way_anova(df, conditions, metric="mae"):
    groups = [df.loc[df["condition"] == c, metric].values for c in conditions]
    groups = [g for g in groups if len(g)]
    f, p = stats.f_oneway(*groups)
    return float(f), float(p), [len(g) for g in groups]


def two_sample_ttest(df, a, b, metric="mae"):
    x = df.loc[df["condition"] == a, metric].values
    y = df.loc[df["condition"] == b, metric].values
    t, p = stats.ttest_ind(x, y, equal_var=False)
    return float(t), float(p), len(x), len(y)


def cohens_d(x, y):
    nx, ny = len(x), len(y)
    sp = np.sqrt(((nx - 1) * np.var(x, ddof=1) +
                  (ny - 1) * np.var(y, ddof=1)) / (nx + ny - 2))
    return float((np.mean(x) - np.mean(y)) / sp) if sp else float("nan")


def bootstrap_cohens_d(x, y, n_boot=1000, seed=1337):
    rng = np.random.default_rng(seed)
    ds = []
    for _ in range(n_boot):
        xs = rng.choice(x, len(x), replace=True)
        ys = rng.choice(y, len(y), replace=True)
        ds.append(cohens_d(xs, ys))
    lo, hi = np.percentile(ds, [2.5, 97.5])
    return cohens_d(x, y), float(lo), float(hi)


def condition_mean_regression(df, conditions):
    means_x, means_y = [], []
    for c in conditions:
        sub = df.loc[df["condition"] == c]
        if len(sub):
            means_x.append(float(sub["mae"].mean()))
            means_y.append(float(sub["rating"].mean()))
    slope, intercept = np.polyfit(means_x, means_y, 1)
    r = float(np.corrcoef(means_x, means_y)[0, 1])
    return float(slope), r, means_x, means_y


# --------------------------------------------------------------------------- #
# Threshold analysis
# --------------------------------------------------------------------------- #
def _tps_design(x, knots):
    """Thin-plate-spline design: [1, x, |x - k|^3 for each knot k]."""
    radial = np.abs(x[:, None] - knots[None, :]) ** 3
    return np.column_stack([np.ones_like(x), x, radial])


def _tps_penalty(knots):
    """Bending-energy penalty; zero on the (intercept, linear) block."""
    K = len(knots)
    omega = np.zeros((2 + K, 2 + K))
    omega[2:, 2:] = np.abs(knots[:, None] - knots[None, :]) ** 3
    return omega


def gam_threshold(df, n_knots=20, lam_grid=None):
    """Penalized thin-plate-spline GAM for MAE (edf + approximate F p-value).

    Self-contained so the pipeline needs no extra GAM package. The smoothing
    parameter is chosen by GCV; the reported edf excludes the intercept and the
    linear term (matching the mgcv convention for a single smooth).
    """
    if lam_grid is None:
        lam_grid = np.logspace(-4, 3, 40)

    x = np.asarray(df["mae"].values, dtype=float)
    y = np.asarray(df["rating"].values, dtype=float)
    n = len(y)

    knots = np.quantile(x, np.linspace(0, 1, n_knots))
    X = _tps_design(x, knots)
    omega = _tps_penalty(knots)

    best = None
    for lam in lam_grid:
        a = X.T @ X + lam * omega
        ainv = np.linalg.pinv(a)
        hat = X @ ainv @ X.T
        edf = float(np.trace(hat))
        rss = float(np.sum((y - hat @ y) ** 2))
        gcv = n * rss / (n - edf) ** 2
        if best is None or gcv < best[0]:
            best = (gcv, lam, edf, rss)

    _, _, edf_total, rss1 = best
    x0 = np.column_stack([np.ones_like(x), x])
    b0 = np.linalg.lstsq(x0, y, rcond=None)[0]
    rss0 = float(np.sum((y - x0 @ b0) ** 2))

    edf_smooth = edf_total - 2.0
    dof_resid = n - edf_total
    if edf_smooth > 0 and dof_resid > 0 and rss1 > 0:
        f_stat = ((rss0 - rss1) / edf_smooth) / (rss1 / dof_resid)
        p = float(1.0 - stats.f.cdf(f_stat, edf_smooth, dof_resid))
    else:
        p = float("nan")
    return edf_smooth, p


def _best_breakpoint(x, y, trim=0.10, min_side=3):
    lo, hi = np.percentile(x, [trim * 100, (1 - trim) * 100])
    best_cp, best_rss = None, np.inf
    for cp in np.unique(x[(x >= lo) & (x <= hi)]):
        left = x <= cp
        right = ~left
        if left.sum() < min_side or right.sum() < min_side:
            continue
        rss = 0.0
        for m in (left, right):
            p = np.polyfit(x[m], y[m], 1)
            rss += float(np.sum((y[m] - np.polyval(p, x[m])) ** 2))
        if rss < best_rss:
            best_cp, best_rss = float(cp), rss
    return best_cp


def segmented_regression(x, y, n_boot=1000, seed=1337):
    """Grid-search change-point (Muggeo-style) plus a bootstrap 95% CI."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    cp = _best_breakpoint(x, y)
    rng = np.random.default_rng(seed)
    boot = []
    for _ in range(n_boot):
        idx = rng.choice(len(x), len(x), replace=True)
        c = _best_breakpoint(x[idx], y[idx])
        if c is not None:
            boot.append(c)
    lo, hi = np.percentile(boot, [2.5, 97.5]) if boot else (np.nan, np.nan)
    return cp, float(lo), float(hi)


# --------------------------------------------------------------------------- #
# Equivalence (TOST)
# --------------------------------------------------------------------------- #
def tost(diff, se, dof, margin=0.10):
    """Two one-sided t-tests; returns the TOST p-value and the 90% CI."""
    t_low = (diff + margin) / se
    t_high = (margin - diff) / se
    p_low = 1.0 - stats.t.cdf(t_low, dof)
    p_high = 1.0 - stats.t.cdf(t_high, dof)
    p = max(p_low, p_high)
    tc = stats.t.ppf(0.95, dof)
    return float(p), (float(diff - tc * se), float(diff + tc * se))


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True)
    parser.add_argument("--margin", type=float, default=0.10,
                        help="TOST equivalence margin in degrees (default 0.10)")
    parser.add_argument("--conditions", nargs="+",
                        default=["C", "D", "E", "G", "H"])
    parser.add_argument("--n-boot", type=int, default=1000)
    args = parser.parse_args()

    df = load_data(args.csv)

    report_mixed_model(df)

    print("\n== Descriptive condition-level tests (metric = MAE) ==")
    pre = [c for c in ("C", "D", "E") if c in set(df["condition"])]
    if len(pre) >= 2:
        f, p, ns = one_way_anova(df, pre)
        print(f"   one-way ANOVA over {'/'.join(pre)}: "
              f"F = {f:.1f}, p = {p:.3g}  (n = {ns})")
    for a, b in (("C", "E"), ("D", "E"), ("E", "G"), ("E", "H")):
        if {a, b} <= set(df["condition"]):
            t, p, na, nb = two_sample_ttest(df, a, b)
            x = df.loc[df["condition"] == a, "mae"].values
            y = df.loc[df["condition"] == b, "mae"].values
            d, lo, hi = bootstrap_cohens_d(x, y, args.n_boot)
            print(f"   {a} vs {b}: t = {t:.1f}, p = {p:.3g}, "
                  f"d = {d:.2f} [{lo:.2f}, {hi:.2f}]  (n = {na}/{nb})")

    print("\n== Condition-mean regression (between-condition, descriptive) ==")
    slope, r, mx, my = condition_mean_regression(df, pre + ["G"] if "G" in set(df["condition"]) else pre)
    print(f"   slope = {slope:.2f}  r = {r:.2f}")

    print("\n== Threshold analysis ==")
    edof, p = gam_threshold(df)
    print(f"   GAM (thin-plate spline): edf = {edof:.2f}, p = {p:.3g}")
    cp, lo, hi = segmented_regression(df["mae"].values, df["rating"].values,
                                      args.n_boot)
    print(f"   segmented regression change-point = {cp:.2f} deg "
          f"(bootstrap 95% CI [{lo:.2f}, {hi:.2f}])")

    if "seed" in df.columns:
        within = df.groupby(["source", "condition"])["mae"].std(ddof=1).dropna()
        if len(within):
            print(f"\n== Seed-level variation ==\n"
                  f"   median within-cell seed SD of MAE = {within.median():.2f} deg "
                  f"(range {within.min():.2f}-{within.max():.2f})")

    print("\n== TOST equivalence (prespecified margin "
          f"{args.margin:.2f} deg) ==")
    if {"ext_mae", "main_mae"} <= set(df.columns):
        x = df["main_mae"].dropna().values
        y = df["ext_mae"].dropna().values
        diff = float(np.mean(y) - np.mean(x))
        se = float(np.sqrt(np.var(x, ddof=1) / len(x) +
                           np.var(y, ddof=1) / len(y)))
        dof = len(x) + len(y) - 2
        p, ci = tost(diff, se, dof, args.margin)
        print(f"   difference = {diff:.2f} deg, SE = {se:.3f}, dof = {dof}")
    else:
        print("   (no ext_mae / main_mae columns; using the paper's worked "
              "example)")
        diff, se, dof = 0.04, 0.025, 80
        p, ci = tost(diff, se, dof, args.margin)
        print(f"   difference = {diff:.2f} deg, SE = {se:.3f}, dof = {dof}")
    print(f"   TOST p = {p:.3f}, 90% CI = ({ci[0]:.3f}, {ci[1]:.3f})")


if __name__ == "__main__":
    main()
