#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PCA intrinsic dimensionality of the Bada Yun training set.

Paper (Section 2.4, "PCA dimensionality (supplementary)"):
  Images were resized to 128x128 and flattened; PCA was performed on the
  training set. The number of components retaining 90% variance was recorded
  over 100 bootstrap iterations.

Reported values: overall 11.4 +/- 2.2 (Song 10.9 +/- 2.1, Shu 11.5 +/- 2.3,
Yun 12.0 +/- 2.4). These are reported as a DESCRIPTIVE complexity measure and
do not justify the rank-8 choice.

Usage:
    python compute_pca.py --image_dir dataset/train
    python compute_pca.py --image_dir dataset/train --by_category
"""

import argparse
import os

import cv2
import numpy as np
from sklearn.decomposition import PCA

SIZE = (128, 128)


def load_vectors(image_dir, size=SIZE):
    """Resize every image to `size` and flatten to a 1-D vector."""
    vectors = []
    for root, _, files in os.walk(image_dir):
        for f in sorted(files):
            if f.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tif")):
                img = cv2.imread(os.path.join(root, f), cv2.IMREAD_GRAYSCALE)
                if img is None:
                    continue
                vectors.append(cv2.resize(img, size).astype(np.float64).ravel())
    if not vectors:
        raise ValueError(f"No valid images found under {image_dir}")
    return np.asarray(vectors, dtype=np.float64)


def intrinsic_dimensionality(X, variance=0.90, n_bootstrap=100, seed=1337):
    """Mean +/- SD number of components retaining `variance`, over bootstrap."""
    rng = np.random.default_rng(seed)
    n_list = []
    for _ in range(n_bootstrap):
        idx = rng.choice(len(X), len(X), replace=True)
        pca = PCA().fit(X[idx])
        cum = np.cumsum(pca.explained_variance_ratio_)
        n_list.append(int(np.searchsorted(cum, variance) + 1))
    return float(np.mean(n_list)), float(np.std(n_list, ddof=1)), n_list


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image_dir", required=True)
    parser.add_argument("--variance", type=float, default=0.90)
    parser.add_argument("--bootstrap", type=int, default=100)
    parser.add_argument("--seed", type=int, default=1337)
    parser.add_argument("--by_category", action="store_true",
                        help="report one line per immediate sub-folder")
    args = parser.parse_args()

    if args.by_category:
        for name in sorted(os.listdir(args.image_dir)):
            sub = os.path.join(args.image_dir, name)
            if not os.path.isdir(sub):
                continue
            X = load_vectors(sub)
            mean_n, std_n, _ = intrinsic_dimensionality(
                X, args.variance, args.bootstrap, args.seed)
            print(f"{name:>12}: n={len(X):3d}  "
                  f"intrinsic dim = {mean_n:.1f} +/- {std_n:.1f}")
        return

    X = load_vectors(args.image_dir)
    mean_n, std_n, _ = intrinsic_dimensionality(
        X, args.variance, args.bootstrap, args.seed)
    print(f"n = {len(X)}  intrinsic dimensionality = {mean_n:.1f} +/- {std_n:.1f}")


if __name__ == "__main__":
    main()
