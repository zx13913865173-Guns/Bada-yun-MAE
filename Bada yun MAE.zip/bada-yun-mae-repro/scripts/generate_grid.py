#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Batch generation driver for the Bada Yun grid (Step 3).

Paper, Section 2.3: the main set followed a
    26 sources x 2 seeds x 5 conditions = 260 images
design, with conditions C, D, E, G and H. Supplementary ablation F used 40
images; A and B are qualitative / non-human references (10 images each).

This driver submits one job per (source, seed, condition) cell to a running
ComfyUI server through its HTTP API and collects the resulting images.

Requirements
------------
* ComfyUI running with `--listen` (the default API endpoint is
  http://127.0.0.1:8188).
* One **API-format** workflow per condition, exported from ComfyUI with
  `Workflow > Export (API)`, stored as `<condition>.json` inside
  `--workflow_dir`. API format is a JSON object keyed by node id, e.g.
      {"5": {"class_type": "LoadImage", "inputs": {"image": "ref.png"}}, ...}
  The condition-specific settings (LoRA file, ControlNet weights, preprocessor
  parameters, sampler settings) live inside each condition's workflow, so the
  driver only overwrites the reference image and the seed.
* A folder of reference images named after the source id, e.g. S01.png ...
  S26.png inside `--refs`.

Usage
-----
    # enumerate the full 260-job grid without contacting ComfyUI
    python generate_grid.py --workflow_dir workflows/api --refs refs --dry-run

    # real run
    python generate_grid.py --workflow_dir workflows/api --refs refs \
        --server http://127.0.0.1:8188 --out_dir generated
"""

import argparse
import json
import os
import shutil
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid


def load_workflow(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def find_node(workflow, node_id):
    if node_id not in workflow:
        raise KeyError(f"node '{node_id}' not present in the API workflow")
    return workflow[node_id]


def build_job(workflow, image_node, seed_node, ref_path, seed):
    job = json.loads(json.dumps(workflow))  # deep copy
    find_node(job, image_node)["inputs"]["image"] = ref_path
    find_node(job, seed_node)["inputs"]["seed"] = int(seed)
    return job


def queue_prompt(server, job, client_id):
    payload = json.dumps({"prompt": job, "client_id": client_id}).encode("utf-8")
    req = urllib.request.Request(f"{server}/prompt", data=payload,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read().decode("utf-8"))["prompt_id"]


def wait_for(server, prompt_id, client_id, timeout=900, interval=1.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        url = (f"{server}/history/{prompt_id}?client_id={client_id}")
        try:
            with urllib.request.urlopen(url) as resp:
                history = json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError:
            history = {}
        if prompt_id in history:
            return history[prompt_id]
        time.sleep(interval)
    raise TimeoutError(f"prompt {prompt_id} did not finish within {timeout}s")


def collect_outputs(server, history, out_dir, cell):
    """Copy every image referenced by a finished job into out_dir."""
    os.makedirs(out_dir, exist_ok=True)
    outputs = history.get("outputs", {})
    saved = []
    for node_id, node in outputs.items():
        for img in node.get("images", []):
            if img.get("type") != "output":
                continue
            query = urllib.parse.urlencode({
                "filename": img["filename"],
                "subfolder": img.get("subfolder", ""),
                "type": img["type"],
            })
            with urllib.request.urlopen(f"{server}/view?{query}") as resp:
                data = resp.read()
            name = f"{cell}_{os.path.basename(img['filename'])}"
            with open(os.path.join(out_dir, name), "wb") as fh:
                fh.write(data)
            saved.append(name)
    return saved


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workflow_dir", required=True,
                        help="folder of API-format workflows named "
                             "<condition>.json")
    parser.add_argument("--refs", required=True,
                        help="folder of reference images named <source>.png")
    parser.add_argument("--conditions", nargs="+",
                        default=["C", "D", "E", "G", "H"])
    parser.add_argument("--seeds", nargs="+", type=int, default=[1, 2])
    parser.add_argument("--sources", nargs="+", default=None,
                        help="source ids; default = every image in --refs")
    parser.add_argument("--image_node", default="5",
                        help="node id of the LoadImage node (API format)")
    parser.add_argument("--seed_node", default="9",
                        help="node id of the KSampler node (API format)")
    parser.add_argument("--server", default="http://127.0.0.1:8188")
    parser.add_argument("--out_dir", default="generated")
    parser.add_argument("--manifest", default="grid_manifest.json")
    parser.add_argument("--dry-run", action="store_true",
                        help="only enumerate the grid, do not contact ComfyUI")
    args = parser.parse_args()

    sources = args.sources
    if sources is None:
        sources = sorted(
            os.path.splitext(f)[0] for f in os.listdir(args.refs)
            if f.lower().endswith((".png", ".jpg", ".jpeg", ".bmp")))

    grid = [(c, s, seed)
            for c in args.conditions
            for s in sources
            for seed in args.seeds]

    manifest = {
        "conditions": args.conditions,
        "sources": sources,
        "seeds": args.seeds,
        "cells": len(grid),
        "jobs": [{"condition": c, "source": s, "seed": seed}
                 for c, s, seed in grid],
    }
    with open(args.manifest, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    print(f"grid: {len(args.conditions)} conditions x {len(sources)} sources "
          f"x {len(args.seeds)} seeds = {len(grid)} jobs")
    print(f"manifest written: {args.manifest}")

    if args.dry_run:
        return

    workflows = {c: load_workflow(os.path.join(args.workflow_dir, f"{c}.json"))
                 for c in args.conditions}
    client_id = str(uuid.uuid4())

    done = 0
    for condition, source, seed in grid:
        ref = os.path.join(args.refs, f"{source}.png")
        if not os.path.exists(ref):
            print(f"  ! missing reference {ref}, skipped")
            continue
        job = build_job(workflows[condition], args.image_node,
                        args.seed_node, ref, seed)
        cell = f"{condition}_{source}_seed{seed}"
        out_dir = os.path.join(args.out_dir, condition, source)
        try:
            prompt_id = queue_prompt(args.server, job, client_id)
            history = wait_for(args.server, prompt_id, client_id)
            saved = collect_outputs(args.server, history, out_dir, cell)
            done += 1
            print(f"  [{done}/{len(grid)}] {cell}: {len(saved)} image(s)")
        except Exception as exc:                       # noqa: BLE001
            print(f"  ! {cell} failed: {exc}")

    print(f"finished: {done}/{len(grid)} jobs")


if __name__ == "__main__":
    main()
