#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Objective image-quality metrics: SSIM / PSNR / LPIPS / FID.

Paper (Section 2.4, "Evaluation Metrics"):
  - SSIM and PSNR were obtained via Fiji.
  - LPIPS and FID were computed offline in PyTorch, with test-set images as
    references.
  - LPIPS and FID were computed for completeness but are NOT used for
    inference, because the test set contains only 26 images and FID is
    unreliable at this scale.

This script provides an equivalent, scriptable implementation of all four
metrics (SSIM/PSNR via scikit-image on 8-bit grayscale, `data_range=255`, which
matches the Fiji output; LPIPS via the `lpips` package; FID via `pytorch-fid`).
Images are matched by sorted filename; pairs are resized to the reference size
when needed.

Usage:
    python evaluate_metrics.py --gen_dir generated/E --ref_dir dataset/test
    python evaluate_metrics.py --gen_dir generated/E --ref_dir dataset/test \
        --skip_fid        # FID is not reliable with n = 26
"""

import argparse
import os

import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio as psnr
from skimage.metrics import structural_similarity as ssim


def list_images(d):
    return sorted(f for f in os.listdir(d)
                  if f.lower().endswith((".png", ".jpg", ".jpeg", ".bmp")))


def compute_ssim_psnr(gen_dir, ref_dir):
    gen_files, ref_files = list_images(gen_dir), list_images(ref_dir)
    n = min(len(gen_files), len(ref_files))
    ssims, psnrs = [], []
    for i in range(n):
        g = cv2.imread(os.path.join(gen_dir, gen_files[i]), cv2.IMREAD_GRAYSCALE)
        r = cv2.imread(os.path.join(ref_dir, ref_files[i]), cv2.IMREAD_GRAYSCALE)
        if g is None or r is None:
            continue
        if g.shape != r.shape:
            g = cv2.resize(g, (r.shape[1], r.shape[0]))
        ssims.append(ssim(r, g, data_range=255))
        psnrs.append(psnr(r, g, data_range=255))
    return float(np.mean(ssims)), float(np.mean(psnrs)), len(ssims)


def compute_lpips(gen_dir, ref_dir, device="cuda"):
    import lpips
    import torch
    loss_fn = lpips.LPIPS(net="alex").to(device)
    gen_files, ref_files = list_images(gen_dir), list_images(ref_dir)
    n = min(len(gen_files), len(ref_files))
    scores = []
    for i in range(n):
        g = lpips.im2tensor(lpips.load_image(
            os.path.join(gen_dir, gen_files[i]))).to(device)
        r = lpips.im2tensor(lpips.load_image(
            os.path.join(ref_dir, ref_files[i]))).to(device)
        if g.shape != r.shape:
            r = torch.nn.functional.interpolate(
                r, size=g.shape[-2:], mode="bilinear", align_corners=False)
        with torch.no_grad():
            scores.append(loss_fn(g, r).item())
    return float(np.mean(scores)), len(scores)


def compute_fid(gen_dir, ref_dir, device="cuda"):
    from pytorch_fid.fid_score import calculate_fid_given_paths
    return calculate_fid_given_paths(
        [gen_dir, ref_dir], batch_size=50, device=device, dims=2048)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gen_dir", required=True)
    parser.add_argument("--ref_dir", required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--skip_fid", action="store_true",
                        help="skip FID (recommended when the reference set is "
                             "small; the paper notes FID is unreliable at n=26)")
    parser.add_argument("--skip_lpips", action="store_true")
    args = parser.parse_args()

    s, p, n = compute_ssim_psnr(args.gen_dir, args.ref_dir)
    print(f"SSIM  = {s:.3f}   (n = {n})")
    print(f"PSNR  = {p:.2f} dB")

    if not args.skip_lpips:
        l, n = compute_lpips(args.gen_dir, args.ref_dir, args.device)
        print(f"LPIPS = {l:.3f}   (n = {n})")

    if not args.skip_fid:
        print(f"FID   = {compute_fid(args.gen_dir, args.ref_dir, args.device):.1f}")


if __name__ == "__main__":
    main()
