#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mean Angular Error (MAE) for line-based ICH pattern evaluation.

Implements the MAE metric exactly as specified in the paper
(Section 2.4, "Mean Angular Error (MAE)"):

  1. Otsu thresholding separates foreground from background.
  2. Zhang-Suen parallel thinning produces a single-pixel-width skeleton.
  3. OpenCV HoughLinesP detects line segments
     (threshold = 50, minLineLength = 50, maxLineGap = 10).
  4. Orientation of each segment is normalised to theta in [0, 180) degrees
     (lines are unoriented, modulo 180 deg). With the canonical axes
         A = {0, 45, 90, 135} degrees,
     the angular deviation of segment i is
         delta_i = min_{a in A} min(|theta_i - a|, 180 - |theta_i - a|),
     which is automatically bounded within [0, 22.5] degrees, and
         MAE = (1 / N) * sum_i delta_i.
     Lower MAE indicates higher angular precision.

Principal-axis correction (`--correct-axis`):
  Direct MAE on arbitrarily rotated inputs is invalid, so the correction
  estimates a dominant orientation and rotates the image until it maps to the
  nearest canonical axis. Because line orientation is circular modulo 180 deg,
  the dominant orientation is estimated in the DOUBLED-ANGLE representation
  (cos 2*theta_i, sin 2*theta_i) weighted by segment length (equivalently, a
  structure-tensor formulation). Naive arithmetic PCA on theta_i is invalid:
  segments near 0 deg and near 180 deg are geometrically almost parallel but
  enter with opposite signed contributions, so their covariance can cancel.
  In the main experiments the generated images were produced in canonical
  orientation and MAE was computed directly WITHOUT correction; applying the
  correction to generated images would remove any global rotation error
  introduced by the model and bias the comparison. The correction is therefore
  used only for the rotated-input sensitivity analysis.

Usage:
    python compute_mae.py --image path/to/image.png
    python compute_mae.py --image path/to/image.png --correct-axis
    python compute_mae.py --image_dir generated/E --csv mae_E.csv
"""

import argparse
import csv
import os

import cv2
import numpy as np

CANONICAL_AXES = (0.0, 45.0, 90.0, 135.0)

# HoughLinesP parameters from the paper
HOUGH_THRESHOLD = 50
HOUGH_MIN_LINE_LENGTH = 50
HOUGH_MAX_LINE_GAP = 10

# Ambiguous-orientation threshold on the length-weighted resultant length R.
# R = |sum_i L_i * (cos 2*theta_i, sin 2*theta_i)| / sum_i L_i  in [0, 1].
AMBIGUITY_THRESHOLD = 0.10


# --------------------------------------------------------------------------- #
# Preprocessing
# --------------------------------------------------------------------------- #
def to_gray(image):
    if image.ndim == 3:
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    return image


def otsu_binarize(gray):
    """Step 1: Otsu thresholding (foreground = 255)."""
    _, binary = cv2.threshold(gray, 0, 255,
                              cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return binary


def zhang_suen_skeleton(binary):
    """Step 2: Zhang-Suen parallel thinning, returning a single-pixel skeleton.

    Self-contained numpy implementation of the classic two-sub-iteration
    algorithm (Zhang & Suen, 1984), equivalent to OpenCV's
    `cv2.ximgproc.thinning(..., THINNING_ZHANGSUEN)`. Keeping it in-script means
    the pipeline runs without opencv-contrib.
    """
    img = (binary > 0).astype(np.uint8)
    changed = True
    while changed:
        changed = False
        for step in (0, 1):
            padded = np.pad(img, 1, mode="constant")
            p2 = padded[0:-2, 1:-1]   # N
            p3 = padded[0:-2, 2:]     # NE
            p4 = padded[1:-1, 2:]     # E
            p5 = padded[2:, 2:]       # SE
            p6 = padded[2:, 1:-1]     # S
            p7 = padded[2:, 0:-2]     # SW
            p8 = padded[1:-1, 0:-2]   # W
            p9 = padded[0:-2, 0:-2]   # NW
            seq = [p2, p3, p4, p5, p6, p7, p8, p9]

            b = sum(seq)
            a = sum(((seq[k] == 0) & (seq[(k + 1) % 8] == 1)).astype(np.uint8)
                    for k in range(8))

            m1 = (b >= 2) & (b <= 6) & (a == 1)
            if step == 0:
                cond = m1 & (p2 * p4 * p6 == 0) & (p4 * p6 * p8 == 0)
            else:
                cond = m1 & (p2 * p4 * p8 == 0) & (p2 * p6 * p8 == 0)

            cond = cond & (img == 1)
            if cond.any():
                img[cond] = 0
                changed = True

    return (img * 255).astype(np.uint8)


# --------------------------------------------------------------------------- #
# Segment detection and angular error
# --------------------------------------------------------------------------- #
def detect_segments(skeleton,
                    threshold=HOUGH_THRESHOLD,
                    min_line_length=HOUGH_MIN_LINE_LENGTH,
                    max_line_gap=HOUGH_MAX_LINE_GAP):
    """Step 3: progressive probabilistic Hough transform."""
    lines = cv2.HoughLinesP(skeleton, 1, np.pi / 180.0,
                            threshold=threshold,
                            minLineLength=min_line_length,
                            maxLineGap=max_line_gap)
    if lines is None:
        return np.empty((0, 4), dtype=float)
    return lines[:, 0].astype(float)


def segment_angles(segments):
    """Unoriented line orientation, expressed in [0, 180) degrees."""
    dx = segments[:, 2] - segments[:, 0]
    dy = segments[:, 3] - segments[:, 1]
    return np.degrees(np.arctan2(dy, dx)) % 180.0


def segment_lengths(segments):
    dx = segments[:, 2] - segments[:, 0]
    dy = segments[:, 3] - segments[:, 1]
    return np.hypot(dx, dy)


def angular_deviations(angles, axes=CANONICAL_AXES):
    """delta_i = min_{a in A} min(|theta_i - a|, 180 - |theta_i - a|)."""
    diff = np.abs(angles[:, None] - np.asarray(axes, dtype=float)[None, :])
    diff = np.minimum(diff, 180.0 - diff)
    return diff.min(axis=1)


# --------------------------------------------------------------------------- #
# Principal-axis correction
# --------------------------------------------------------------------------- #
def dominant_orientation(angles, lengths):
    """Length-weighted doubled-angle dominant orientation, in [0, 180)."""
    two_theta = np.radians(2.0 * angles)
    c = float(np.sum(lengths * np.cos(two_theta)))
    s = float(np.sum(lengths * np.sin(two_theta)))
    return (0.5 * np.degrees(np.arctan2(s, c))) % 180.0


def orientation_resultant_length(angles, lengths):
    """R in [0, 1]; small R means the dominant orientation is ambiguous."""
    two_theta = np.radians(2.0 * angles)
    c = float(np.sum(lengths * np.cos(two_theta)))
    s = float(np.sum(lengths * np.sin(two_theta)))
    total = float(np.sum(lengths)) or 1.0
    return float(np.hypot(c, s) / total)


def nearest_axis(angle, axes=CANONICAL_AXES):
    best, best_dev = axes[0], float("inf")
    for a in axes:
        dev = min(abs(angle - a), 180.0 - abs(angle - a))
        if dev < best_dev:
            best, best_dev = a, dev
    return best


def rotate_image(gray, angle_deg):
    h, w = gray.shape[:2]
    m = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), angle_deg, 1.0)
    return cv2.warpAffine(gray, m, (w, h),
                          flags=cv2.INTER_LINEAR,
                          borderMode=cv2.BORDER_REPLICATE)


# --------------------------------------------------------------------------- #
# MAE
# --------------------------------------------------------------------------- #
def compute_mae(image, axes=CANONICAL_AXES, correct_axis=False, return_qc=False):
    gray = to_gray(image)
    binary = otsu_binarize(gray)
    skeleton = zhang_suen_skeleton(binary)
    segments = detect_segments(skeleton)

    rotation_applied = 0.0
    ambiguity = False

    if len(segments):
        angles0 = segment_angles(segments)
        lengths0 = segment_lengths(segments)
        rl = orientation_resultant_length(angles0, lengths0)
        ambiguity = bool(rl < AMBIGUITY_THRESHOLD)

    # Apply the correction only when a dominant orientation actually exists.
    # For an exactly four-axis-symmetric pattern the doubled-angle vectors
    # cancel (R = 0), so no dominant orientation is defined and rotating would
    # be meaningless; such inputs keep the ambiguity flag instead.
    if correct_axis and len(segments) and not ambiguity:
        dom = dominant_orientation(angles0, lengths0)
        rotation_applied = dom - nearest_axis(dom, axes)
        gray = rotate_image(gray, rotation_applied)
        binary = otsu_binarize(gray)
        skeleton = zhang_suen_skeleton(binary)
        segments = detect_segments(skeleton)

    if len(segments) == 0:
        value = float("nan")
        qc = {"n_segments": 0, "rotation_deg": rotation_applied,
              "max_deviation": float("nan"), "ambiguity_flag": ambiguity}
    else:
        devs = angular_deviations(segment_angles(segments), axes)
        value = float(np.mean(devs))
        qc = {"n_segments": int(len(segments)),
              "rotation_deg": float(rotation_applied),
              "max_deviation": float(np.max(devs)),
              "ambiguity_flag": ambiguity}

    if return_qc:
        return value, qc
    return value


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #
def _iter_images(image_dir):
    for root, _, files in os.walk(image_dir):
        for f in sorted(files):
            if f.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tif")):
                yield os.path.join(root, f)


def main():
    parser = argparse.ArgumentParser(
        description="Mean Angular Error (MAE) for line-based ICH patterns.")
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--image", help="single image file")
    src.add_argument("--image_dir", help="directory of images (batch mode)")
    parser.add_argument("--csv", help="output CSV path (batch mode)")
    parser.add_argument("--axes", type=float, nargs="+",
                        default=list(CANONICAL_AXES),
                        help="canonical axes, default 0 45 90 135")
    parser.add_argument("--correct-axis", action="store_true",
                        help="apply doubled-angle principal-axis correction "
                             "(sensitivity analysis on rotated inputs only)")
    args = parser.parse_args()

    axes = tuple(args.axes)

    if args.image:
        img = cv2.imread(args.image, cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(args.image)
        value, qc = compute_mae(img, axes, args.correct_axis, return_qc=True)
        print(f"MAE = {value:.2f} deg  "
              f"(segments={qc['n_segments']}, "
              f"rotation={qc['rotation_deg']:.2f} deg, "
              f"max_dev={qc['max_deviation']:.2f} deg, "
              f"ambiguity={qc['ambiguity_flag']})")
        return

    rows = []
    for path in _iter_images(args.image_dir):
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            continue
        value, qc = compute_mae(img, axes, args.correct_axis, return_qc=True)
        rows.append({"file": os.path.relpath(path, args.image_dir),
                     "mae": value, **qc})

    if not rows:
        raise SystemExit(f"No images found in {args.image_dir}")

    values = np.array([r["mae"] for r in rows], dtype=float)
    print(f"n = {len(rows)}  MAE = {np.nanmean(values):.2f} "
          f"+/- {np.nanstd(values, ddof=1):.2f} deg")

    if args.csv:
        with open(args.csv, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(
                fh, fieldnames=["file", "mae", "n_segments",
                                "rotation_deg", "max_deviation",
                                "ambiguity_flag"])
            writer.writeheader()
            writer.writerows(rows)
        print(f"written: {args.csv}")


if __name__ == "__main__":
    main()
